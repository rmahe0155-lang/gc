# Gilbet Cafe — Combined Website + Backend

This is one website project: the existing Gilbet Cafe customer page is served by the same Node.js app as the order API and admin dashboard.

## Included
- Customer website and menu
- Delivery and pickup order selection
- Server-side order total calculation and SQLite order storage
- Admin login and order list
- Manual payment confirmation in the admin dashboard
- Email notification code addressed to `rmahe0155@gmail.com`

## Run locally
1. Install Node.js 20 or newer.
2. Open this project folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set a long random `SESSION_SECRET` and a strong `ADMIN_PASSWORD` (at least 12 characters).
6. To enable email, configure SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, EMAIL_FROM with a verified sender, and keep EMAIL_TO as `rmahe0155@gmail.com`.
7. Run `npm start` and open `http://localhost:3000`.

## Important before real customer use
- Email delivery will remain disabled until the cafe owner configures a legitimate SMTP/email provider. Never share email passwords, app passwords, OTPs, or API secrets in chat or in frontend HTML.
- PhonePe Payment Gateway has **not** been integrated yet. The existing cafe UPI ID / QR route is manual UPI; the admin must independently check the bank or merchant account before confirming payment. A customer-entered UPI reference is not proof of payment.
- PhonePe automatic payment verification requires an approved merchant account, official server-side API integration, callbacks/webhooks, and signature/status verification.
- The sample server-side menu is the six items in the current website. Confirm prices and availability with the cafe owner before publishing.
- Configure HTTPS, persistent hosting/database/session storage, backups, and production security before launch. Do not expose `.env` or the SQLite database publicly.
- Admin menu editing and customer review syncing remain local/demo features; order creation and order management use the backend.

## Admin
The admin password is set only in `.env` as `ADMIN_PASSWORD`. There is no demo password in the website source.
