require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const nodemailer = require("nodemailer");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const required = ["SESSION_SECRET", "ADMIN_PASSWORD"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing environment settings:", missing.join(", "));
  process.exit(1);
}
if (process.env.ADMIN_PASSWORD.length < 12) {
  console.error("ADMIN_PASSWORD must be at least 12 characters.");
  process.exit(1);
}

app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(session({
  name: "gilbet_admin",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));

const db = new Database(process.env.DB_FILE || path.join(__dirname, "gilbet.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 order_number TEXT NOT NULL UNIQUE,
 customer_name TEXT NOT NULL,
 phone TEXT NOT NULL,
 order_type TEXT NOT NULL CHECK(order_type IN ('delivery','pickup')),
 address TEXT NOT NULL DEFAULT '',
 notes TEXT NOT NULL DEFAULT '',
 items_json TEXT NOT NULL,
 amount INTEGER NOT NULL,
 payment_method TEXT NOT NULL DEFAULT 'upi_qr',
 payment_status TEXT NOT NULL DEFAULT 'pending',
 payment_reference TEXT NOT NULL DEFAULT '',
 status TEXT NOT NULL DEFAULT 'Awaiting payment',
 created_at TEXT NOT NULL
);
`);

const catalog = {
  1: { name: "Classic Cappuccino", price: 140 },
  2: { name: "Cold Coffee", price: 160 },
  3: { name: "Chocolate Cake", price: 180 },
  4: { name: "Choco Chip Cookies", price: 90 },
  5: { name: "Veg Sandwich", price: 130 },
  6: { name: "French Fries", price: 110 }
};

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const orderLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });
const clean = (v, n) => String(v || "").trim().slice(0, n);
const safeEqual = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
async function sendOrderEmail(order) {
  const requiredMail = ["SMTP_HOST", "SMTP_USER", "SMTP_PASS", "EMAIL_FROM", "EMAIL_TO"];
  if (requiredMail.some(k => !process.env[k])) {
    console.warn("Email notification skipped: SMTP settings are not configured.");
    return false;
  }
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  const lines = order.items.map(i => `${i.name} x ${i.quantity} - Rs.${i.unitPrice * i.quantity}`).join("\n");
  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to: process.env.EMAIL_TO,
    subject: `Gilbet Cafe - New order ${order.orderNumber}`,
    text: `New Gilbet Cafe order\nOrder: ${order.orderNumber}\nCustomer: ${order.customerName}\nPhone: ${order.phone}\nType: ${order.orderType}\nAddress: ${order.address || "Pickup"}\nItems:\n${lines}\nTotal: Rs.${order.amount}\nPayment: Pending manual verification`
  });
  return true;
}
function adminOnly(req, res, next) {
  if (req.session?.isAdmin !== true) return res.status(401).json({ error: "Admin login required." });
  next();
}

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "Gilbet Cafe backend", paymentIntegration: "not-configured" }));
app.get("/api/menu", (_req, res) => res.json({ items: Object.entries(catalog).map(([id, p]) => ({ id: Number(id), ...p })) }));

// Gateway-neutral order creation. It does NOT claim a payment is successful.
app.post("/api/orders", orderLimiter, (req, res) => {
  try {
    const b = req.body || {}, c = b.customer || {};
    const name = clean(c.name, 90), phone = clean(c.phone, 18);
    const orderType = b.orderType === "pickup" ? "pickup" : "delivery";
    const address = orderType === "delivery" ? clean(c.address, 600) : "";
    const notes = clean(c.notes, 300);
    if (!name || !phone || (orderType === "delivery" && !address))
      return res.status(400).json({ error: "Please enter name, phone and delivery address if delivery is selected." });

    const incoming = Array.isArray(b.items) ? b.items : [];
    if (!incoming.length || incoming.length > 30) return res.status(400).json({ error: "Cart is empty or invalid." });
    const items = []; let total = 0;
    for (const line of incoming) {
      const p = catalog[Number(line.id)], qty = Number(line.quantity);
      if (!p || !Number.isInteger(qty) || qty < 1 || qty > 20)
        return res.status(400).json({ error: "Invalid cart item. Refresh the menu and try again." });
      items.push({ id: Number(line.id), name: p.name, quantity: qty, unitPrice: p.price });
      total += p.price * qty;
    }
    if (total < 1 || total > 100000) return res.status(400).json({ error: "Order total is outside the allowed range." });

    const orderNumber = "GC" + Date.now().toString().slice(-8) + crypto.randomBytes(2).toString("hex").toUpperCase();
    const result = db.prepare(`INSERT INTO orders
      (order_number,customer_name,phone,order_type,address,notes,items_json,amount,payment_method,payment_status,status,created_at)
      VALUES (?,?,?,?,?,?,?,?,?,'pending','Awaiting payment',?)`)
      .run(orderNumber, name, phone, orderType, address, notes, JSON.stringify(items), total, "upi_qr", new Date().toISOString());

    const orderForEmail = { orderNumber, customerName: name, phone, orderType, address, items, amount: total };
    sendOrderEmail(orderForEmail).catch(err => console.error("Order email failed:", err.message));
    res.status(201).json({
      ok: true, orderId: Number(result.lastInsertRowid), orderNumber, amount: total,
      currency: "INR", paymentStatus: "pending",
      message: "Order created. Payment must be independently confirmed before preparation."
    });
  } catch (e) {
    console.error("Order creation failed:", e.message);
    res.status(500).json({ error: "Could not create order. Please try again." });
  }
});

// Customer may submit a reference for admin review; this does not verify bank payment.
app.post("/api/orders/:id/payment-reference", orderLimiter, (req, res) => {
  const ref = clean((req.body || {}).reference, 100);
  if (!ref) return res.status(400).json({ error: "Enter the UPI transaction reference." });
  const result = db.prepare("UPDATE orders SET payment_reference=? WHERE id=? AND payment_status='pending'")
    .run(ref, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Pending order not found." });
  res.json({ ok: true, message: "Reference submitted for cafe admin review. Payment is not yet verified." });
});

app.post("/api/admin/login", loginLimiter, (req, res) => {
  const password = String((req.body || {}).password || "");
  if (!safeEqual(password, process.env.ADMIN_PASSWORD)) return res.status(401).json({ error: "Incorrect admin password." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start admin session." });
    req.session.isAdmin = true;
    res.json({ ok: true });
  });
});
app.post("/api/admin/logout", (req, res) => req.session.destroy(() => res.json({ ok: true })));
app.get("/api/admin/orders", adminOnly, (_req, res) => {
  const rows = db.prepare("SELECT * FROM orders ORDER BY id DESC LIMIT 200").all();
  res.json({ orders: rows.map(o => ({
    id:o.id, orderNumber:o.order_number, customerName:o.customer_name, phone:o.phone,
    orderType:o.order_type, address:o.address, notes:o.notes, items:JSON.parse(o.items_json),
    amount:o.amount, paymentStatus:o.payment_status, paymentReference:o.payment_reference,
    status:o.status, createdAt:o.created_at
  })) });
});
app.patch("/api/admin/orders/:id/payment", adminOnly, (req, res) => {
  const action = (req.body || {}).action;
  if (!["confirm","reject"].includes(action)) return res.status(400).json({ error: "Action must be confirm or reject." });
  const status = action === "confirm" ? "paid" : "rejected";
  const result = db.prepare("UPDATE orders SET payment_status=?, status=? WHERE id=? AND payment_status='pending'")
    .run(status, action === "confirm" ? "Confirmed" : "Payment rejected", Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Pending order not found." });
  res.json({ ok: true, paymentStatus: status });
});
app.patch("/api/admin/orders/:id/status", adminOnly, (req, res) => {
  const allowed = ["Confirmed","Preparing","Ready for pickup","Out for Delivery","Delivered","Cancelled"];
  const status = String((req.body || {}).status || "");
  if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid order status." });
  const result = db.prepare("UPDATE orders SET status=? WHERE id=? AND payment_status='paid'").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Paid order not found." });
  res.json({ ok: true });
});

app.use(express.static(path.join(__dirname, "public")));
app.listen(PORT, () => console.log(`Gilbet Cafe backend listening on port ${PORT}`));
